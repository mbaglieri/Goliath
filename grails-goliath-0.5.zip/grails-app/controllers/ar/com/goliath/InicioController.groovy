package ar.com.goliath

class InicioController {

    def index = {
        
        render(view:'index')
    }
}

// JavaScript Document

/*$().ready(function(){
	$("h1").css("font-size","3em;" );
	$("h2").css("font-size","2em;" );
	$("h3").css("font-size","1.5em;" );
	$("h4").css("font-size","1.2em;" );	
	$("h5").css("font-size","1em;" );		
	$("#tweet").css("font-size","2em");

});*/

Cufon.replace('h1');
Cufon.replace('h2');
Cufon.replace('h3');
Cufon.replace('h4');
Cufon.replace('h5');
Cufon.replace('h6');